import { NextRequest, NextResponse } from 'next/server';
import { createVoiceModel, FishAudioApiError, FishAudioConfigError } from '@/lib/fish-audio';
import { sanitizeVoiceName, validateAudioFile, validateVoiceName } from '@/lib/validation';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  const clientKey = getClientKey(request);
  const rateLimit = checkRateLimit(`create:${clientKey}`, { limit: 5, windowMs: 10 * 60 * 1000 });

  if (!rateLimit.allowed) {
    return NextResponse.json(
      { success: false, error: 'Too many voice creation requests. Please wait a bit and try again.' },
      { status: 429, headers: rateLimit.retryAfterSeconds ? { 'Retry-After': String(rateLimit.retryAfterSeconds) } : undefined }
    );
  }

  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json({ success: false, error: 'Invalid request format.' }, { status: 400 });
  }

  const file = formData.get('audio');
  const rawName = formData.get('voiceName');
  const voiceName = typeof rawName === 'string' ? rawName : '';

  const audioFile = file instanceof File ? file : null;

  const audioValidation = validateAudioFile(audioFile);
  if (!audioValidation.valid) {
    return NextResponse.json({ success: false, error: audioValidation.error }, { status: 400 });
  }

  const nameValidation = validateVoiceName(voiceName);
  if (!nameValidation.valid) {
    return NextResponse.json({ success: false, error: nameValidation.error }, { status: 400 });
  }

  if (!process.env.FISH_API_KEY) {
    return NextResponse.json(
      { success: false, error: 'Voice generation is not configured on the server yet.' },
      { status: 503 }
    );
  }

  try {
    const arrayBuffer = await audioFile!.arrayBuffer();
    const result = await createVoiceModel({
      title: sanitizeVoiceName(voiceName),
      audio: Buffer.from(arrayBuffer),
      filename: audioFile!.name || 'sample.wav',
      mimeType: audioFile!.type || 'audio/wav',
    });

    return NextResponse.json({
      success: true,
      voiceId: result.id,
      state: result.state,
      title: result.title,
    });
  } catch (err) {
    if (err instanceof FishAudioConfigError) {
      return NextResponse.json(
        { success: false, error: 'Voice generation is not configured on the server yet.' },
        { status: 503 }
      );
    }
    if (err instanceof FishAudioApiError) {
      return NextResponse.json({ success: false, error: err.message }, { status: err.status || 502 });
    }
    return NextResponse.json(
      { success: false, error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
