import { NextRequest, NextResponse } from 'next/server';
import { generateSpeech, FishAudioApiError, FishAudioConfigError } from '@/lib/fish-audio';
import {
  clampSpeed,
  clampVolume,
  validateGenerationText,
  validateVoiceId,
} from '@/lib/validation';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  const clientKey = getClientKey(request);
  const rateLimit = checkRateLimit(`generate:${clientKey}`, { limit: 15, windowMs: 10 * 60 * 1000 });

  if (!rateLimit.allowed) {
    return NextResponse.json(
      { success: false, error: 'Too many generation requests. Please wait a bit and try again.' },
      { status: 429, headers: rateLimit.retryAfterSeconds ? { 'Retry-After': String(rateLimit.retryAfterSeconds) } : undefined }
    );
  }

  let body: { text?: string; voiceId?: string; speed?: number; volume?: number };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ success: false, error: 'Invalid request format.' }, { status: 400 });
  }

  const text = typeof body.text === 'string' ? body.text : '';
  const voiceId = typeof body.voiceId === 'string' ? body.voiceId : '';

  const textValidation = validateGenerationText(text);
  if (!textValidation.valid) {
    return NextResponse.json({ success: false, error: textValidation.error }, { status: 400 });
  }

  const voiceValidation = validateVoiceId(voiceId);
  if (!voiceValidation.valid) {
    return NextResponse.json({ success: false, error: voiceValidation.error }, { status: 400 });
  }

  if (!process.env.FISH_API_KEY) {
    return NextResponse.json(
      { success: false, error: 'Voice generation is not configured on the server yet.' },
      { status: 503 }
    );
  }

  const speed = clampSpeed(typeof body.speed === 'number' ? body.speed : 1);
  const volume = clampVolume(typeof body.volume === 'number' ? body.volume : 0);

  try {
    const result = await generateSpeech({
      text: text.trim(),
      referenceId: voiceId,
      speed,
      volume,
    });

    return new NextResponse(result.audio, {
      status: 200,
      headers: {
        'Content-Type': result.contentType,
        'Content-Length': String(result.audio.byteLength),
        'Cache-Control': 'no-store',
      },
    });
  } catch (err) {
    if (err instanceof FishAudioConfigError) {
      return NextResponse.json(
        { success: false, error: 'Voice generation is not configured on the server yet.' },
        { status: 503 }
      );
    }
    if (err instanceof FishAudioApiError) {
      return NextResponse.json({ success: false, error: err.message }, { status: err.status || 502 });
    }
    return NextResponse.json(
      { success: false, error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
