'use client';

import { useRef, useState } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { VoiceCreator } from '@/components/VoiceCreator';
import { TextGenerator } from '@/components/TextGenerator';
import { AudioPlayer } from '@/components/AudioPlayer';
import { Footer } from '@/components/Footer';

export default function Home() {
  const [voiceId, setVoiceId] = useState<string | null>(null);
  const [voiceTitle, setVoiceTitle] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const previousUrlRef = useRef<string | null>(null);

  function handleVoiceReady(id: string, title: string) {
    setVoiceId(id);
    setVoiceTitle(title);
    setAudioUrl(null);
  }

  function handleReset() {
    setVoiceId(null);
    setVoiceTitle(null);
    setAudioUrl(null);
  }

  function handleAudioGenerated(url: string) {
    if (previousUrlRef.current) {
      URL.revokeObjectURL(previousUrlRef.current);
    }
    previousUrlRef.current = url;
    setAudioUrl(url);
  }

  return (
    <main className="min-h-screen safe-bottom">
      <Header />
      <Hero />

      <section id="voice-clone-section" className="mx-auto max-w-2xl space-y-6 px-4 pb-20 sm:px-6">
        <VoiceCreator onVoiceReady={handleVoiceReady} readyVoiceTitle={voiceTitle} onReset={handleReset} />

        {voiceId && <TextGenerator voiceId={voiceId} onAudioGenerated={handleAudioGenerated} />}

        {audioUrl && <AudioPlayer audioUrl={audioUrl} />}
      </section>

      <Footer />
    </main>
  );
}
