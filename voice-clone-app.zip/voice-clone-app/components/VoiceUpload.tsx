'use client';

import { useRef, useState } from 'react';
import { validateAudioFile } from '@/lib/validation';
import { MAX_AUDIO_BYTES } from '@/lib/types';

export function VoiceUpload({
  file,
  onFileSelected,
  onError,
  disabled,
}: {
  file: File | null;
  onFileSelected: (file: File | null) => void;
  onError: (message: string) => void;
  disabled?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  function handleFiles(fileList: FileList | null) {
    const selected = fileList?.[0] ?? null;
    const result = validateAudioFile(selected);
    if (!result.valid) {
      onError(result.error || 'Please upload a valid audio file.');
      onFileSelected(null);
      return;
    }
    onFileSelected(selected);
  }

  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-ink-300" htmlFor="voice-sample-input">
        Voice sample
      </label>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (!disabled) handleFiles(e.dataTransfer.files);
        }}
        onClick={() => !disabled && inputRef.current?.click()}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-disabled={disabled}
        onKeyDown={(e) => {
          if (!disabled && (e.key === 'Enter' || e.key === ' ')) inputRef.current?.click();
        }}
        className={`flex min-h-[168px] cursor-pointer flex-col items-center justify-center gap-3 rounded-xl2 border-2 border-dashed px-4 py-8 text-center transition-colors ${
          disabled ? 'cursor-not-allowed opacity-50' : ''
        } ${
          isDragging
            ? 'border-signal-violet bg-signal-violet/10'
            : 'border-base-600 bg-base-800/60 hover:border-signal-violet/60 hover:bg-base-800'
        }`}
      >
        <input
          ref={inputRef}
          id="voice-sample-input"
          type="file"
          accept=".wav,.mp3,.m4a,.opus,.ogg,audio/*"
          className="hidden"
          disabled={disabled}
          onChange={(e) => handleFiles(e.target.files)}
        />

        <svg
          width="32"
          height="32"
          viewBox="0 0 24 24"
          fill="none"
          className="text-signal-teal"
          aria-hidden="true"
        >
          <path
            d="M12 16V4m0 0L7 9m5-5l5 5"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M4 16v2a3 3 0 003 3h10a3 3 0 003-3v-2"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>

        {file ? (
          <div className="w-full max-w-xs">
            <p className="truncate text-sm font-medium text-ink-100">{file.name}</p>
            <p className="mt-0.5 text-xs text-ink-500">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
          </div>
        ) : (
          <div>
            <p className="text-sm font-medium text-ink-100 sm:text-base">
              Tap to upload, or drag & drop
            </p>
            <p className="mt-1 text-xs text-ink-500">
              WAV, MP3, M4A, or OPUS · up to {Math.round(MAX_AUDIO_BYTES / (1024 * 1024))}MB
            </p>
          </div>
        )}
      </div>

      {file && (
        <button
          type="button"
          disabled={disabled}
          onClick={(e) => {
            e.stopPropagation();
            onFileSelected(null);
            if (inputRef.current) inputRef.current.value = '';
          }}
          className="mt-3 text-sm font-medium text-signal-red transition-opacity hover:opacity-80 disabled:opacity-40"
        >
          Remove file
        </button>
      )}
    </div>
  );
}
