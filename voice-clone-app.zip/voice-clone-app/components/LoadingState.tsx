'use client';

import { Waveform } from './Waveform';

export function LoadingState({ label }: { label: string }) {
  return (
    <div className="flex items-center justify-center gap-3 rounded-lg bg-base-800/60 px-4 py-3" role="status" aria-live="polite">
      <Waveform active size="sm" className="w-16" />
      <span className="text-sm font-medium text-ink-300">{label}</span>
    </div>
  );
}
