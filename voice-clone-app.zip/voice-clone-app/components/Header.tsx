'use client';

import { Waveform } from './Waveform';

export function Header() {
  const scrollToClone = () => {
    document.getElementById('voice-clone-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 border-b border-base-border/80 bg-base-950/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3 sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-signal-gradient shadow-glow">
            <Waveform active size="sm" className="h-4 scale-90" />
          </span>
          <span className="font-display text-[15px] font-semibold tracking-tight text-ink-100 sm:text-base">
            Fable<span className="text-signal-teal">Voice</span>
          </span>
        </div>

        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={scrollToClone}
            className="rounded-full bg-base-800 px-3.5 py-2 text-sm font-medium text-ink-100 ring-1 ring-inset ring-signal-violet/40 transition-colors hover:bg-base-700 sm:px-4"
          >
            Voice Clone
          </button>
        </nav>
      </div>
    </header>
  );
}
