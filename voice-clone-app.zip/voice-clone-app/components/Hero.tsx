'use client';

import { Waveform } from './Waveform';

export function Hero() {
  const scrollToClone = () => {
    document.getElementById('voice-clone-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative overflow-hidden bg-radial-fade px-4 pb-14 pt-14 sm:px-6 sm:pb-20 sm:pt-20">
      <div className="mx-auto max-w-3xl text-center">
        <div className="mb-6 flex justify-center">
          <Waveform active size="lg" className="opacity-90" />
        </div>

        <h1 className="animate-fade-up font-display text-[2.1rem] font-semibold leading-[1.1] tracking-tight text-ink-100 sm:text-6xl">
          AI Voice Cloning
        </h1>

        <p
          className="mx-auto mt-4 max-w-md animate-fade-up text-balance text-base leading-relaxed text-ink-500 sm:max-w-xl sm:text-lg"
          style={{ animationDelay: '0.08s' }}
        >
          Create natural-sounding speech from your own voice.
        </p>

        <div className="mt-8 flex animate-fade-up justify-center" style={{ animationDelay: '0.16s' }}>
          <button
            onClick={scrollToClone}
            className="rounded-full bg-signal-gradient px-7 py-3.5 text-base font-semibold text-base-950 shadow-glow transition-transform active:scale-95 sm:px-8"
          >
            Create Voice
          </button>
        </div>
      </div>
    </section>
  );
}
