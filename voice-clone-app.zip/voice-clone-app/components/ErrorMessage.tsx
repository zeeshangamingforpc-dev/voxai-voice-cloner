'use client';

export function ErrorMessage({ message }: { message: string | null }) {
  if (!message) return null;

  return (
    <div
      role="alert"
      className="mt-3 flex items-start gap-2 rounded-lg border border-signal-red/30 bg-signal-red/10 px-3.5 py-2.5 text-sm text-signal-red"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="mt-0.5 shrink-0" aria-hidden="true">
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8" />
        <path d="M12 8v5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        <circle cx="12" cy="16" r="1" fill="currentColor" />
      </svg>
      <span>{message}</span>
    </div>
  );
}
