'use client';

import { useState } from 'react';
import { ErrorMessage } from './ErrorMessage';
import { LoadingState } from './LoadingState';
import { validateGenerationText } from '@/lib/validation';
import { MAX_TEXT_LENGTH, SPEED_MAX, SPEED_MIN, VOLUME_MAX, VOLUME_MIN } from '@/lib/types';

const EMOTION_TAGS = ['[happy]', '[sad]', '[excited]', '[whisper]', '[laugh]', '[sigh]'];

interface TextGeneratorProps {
  voiceId: string;
  onAudioGenerated: (audioUrl: string) => void;
}

export function TextGenerator({ voiceId, onAudioGenerated }: TextGeneratorProps) {
  const [text, setText] = useState('');
  const [speed, setSpeed] = useState(1);
  const [volume, setVolume] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const remaining = MAX_TEXT_LENGTH - text.length;

  function insertTag(tag: string) {
    setText((prev) => (prev.length + tag.length + 1 <= MAX_TEXT_LENGTH ? `${prev}${prev ? ' ' : ''}${tag}` : prev));
  }

  async function handleGenerate() {
    setError(null);

    const check = validateGenerationText(text);
    if (!check.valid) {
      setError(check.error || 'Please enter some text first.');
      return;
    }

    setIsGenerating(true);

    try {
      const response = await fetch('/api/voice/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text.trim(), voiceId, speed, volume }),
      });

      if (!response.ok) {
        let message = 'Something went wrong. Please try again.';
        try {
          const data = await response.json();
          if (data?.error) message = data.error;
        } catch {
          // response wasn't JSON; keep generic message
        }
        setError(message);
        return;
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      onAudioGenerated(url);
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  }

  return (
    <div className="rounded-xl2 border border-base-border bg-base-800/70 p-5 shadow-card sm:p-6">
      <h2 className="font-display text-xl font-semibold text-ink-100">Generate Speech</h2>

      <div className="mt-5">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, MAX_TEXT_LENGTH))}
          placeholder="Type something you want your voice to say..."
          disabled={isGenerating}
          rows={5}
          aria-label="Text to convert to speech"
          className="w-full resize-none rounded-lg border border-base-border bg-base-900 px-3.5 py-3 text-base leading-relaxed text-ink-100 placeholder:text-ink-700 focus:border-signal-violet disabled:opacity-50"
        />
        <div className="mt-2 flex items-center justify-between text-xs text-ink-700">
          <span className="font-mono">{text.length} / {MAX_TEXT_LENGTH}</span>
          {text.length > 0 && (
            <button type="button" onClick={() => setText('')} disabled={isGenerating} className="font-medium text-ink-500 hover:text-ink-300">
              Clear
            </button>
          )}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {EMOTION_TAGS.map((tag) => (
          <button
            key={tag}
            type="button"
            disabled={isGenerating || remaining < tag.length + 1}
            onClick={() => insertTag(tag)}
            className="rounded-full border border-base-border bg-base-900 px-3 py-1.5 text-xs font-medium text-ink-300 transition-colors hover:border-signal-teal/50 hover:text-signal-teal disabled:opacity-40"
          >
            {tag}
          </button>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div>
          <div className="mb-2 flex items-center justify-between text-sm">
            <label htmlFor="speed-range" className="font-medium text-ink-300">Speed</label>
            <span className="font-mono text-xs text-ink-500">{speed.toFixed(2)}x</span>
          </div>
          <input
            id="speed-range"
            type="range"
            min={SPEED_MIN}
            max={SPEED_MAX}
            step={0.05}
            value={speed}
            disabled={isGenerating}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between text-sm">
            <label htmlFor="volume-range" className="font-medium text-ink-300">Volume</label>
            <span className="font-mono text-xs text-ink-500">{volume > 0 ? `+${volume}` : volume} dB</span>
          </div>
          <input
            id="volume-range"
            type="range"
            min={VOLUME_MIN}
            max={VOLUME_MAX}
            step={1}
            value={volume}
            disabled={isGenerating}
            onChange={(e) => setVolume(parseInt(e.target.value, 10))}
            className="w-full"
          />
        </div>
      </div>

      <ErrorMessage message={error} />

      <div className="mt-6">
        {isGenerating ? (
          <LoadingState label="Generating voice..." />
        ) : (
          <button
            type="button"
            onClick={handleGenerate}
            className="w-full rounded-full bg-signal-gradient px-6 py-3.5 text-base font-semibold text-base-950 shadow-glow transition-transform active:scale-95 sm:w-auto"
          >
            Generate Speech
          </button>
        )}
      </div>
    </div>
  );
}
