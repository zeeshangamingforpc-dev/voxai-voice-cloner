'use client';

const BAR_COUNT = 24;
// Fixed heights + delays give a natural, non-repetitive-looking ripple
// without any randomness that would cause hydration mismatches.
const HEIGHTS = [0.3, 0.55, 0.8, 0.45, 1, 0.6, 0.35, 0.9, 0.5, 0.7, 0.4, 0.85, 0.55, 0.3, 0.95, 0.5, 0.65, 0.4, 0.8, 0.45, 0.6, 0.35, 0.9, 0.5];

export function Waveform({
  active = true,
  className = '',
  size = 'md',
}: {
  active?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}) {
  const heightClass = size === 'lg' ? 'h-16' : size === 'sm' ? 'h-6' : 'h-10';
  const widthClass = size === 'lg' ? 'w-1.5' : 'w-1';

  return (
    <div
      className={`flex items-end gap-[3px] ${heightClass} ${className}`}
      role="img"
      aria-label={active ? 'Audio waveform, playing' : 'Audio waveform, idle'}
    >
      {HEIGHTS.slice(0, BAR_COUNT).map((h, i) => (
        <span
          key={i}
          className={`${widthClass} rounded-full bg-signal-gradient origin-bottom ${
            active ? 'animate-bar-bounce' : ''
          }`}
          style={{
            height: `${h * 100}%`,
            animationDelay: `${(i % 8) * 0.09}s`,
            opacity: active ? 1 : 0.35,
            transform: active ? undefined : `scaleY(${Math.max(h, 0.15)})`,
          }}
        />
      ))}
    </div>
  );
}
