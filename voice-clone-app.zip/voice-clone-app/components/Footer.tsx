export function Footer() {
  return (
    <footer className="border-t border-base-border px-4 py-8 sm:px-6">
      <div className="mx-auto max-w-5xl text-center text-xs text-ink-700">
        <p>Built with Fish Audio. Speech generation happens through Fish Audio's API.</p>
      </div>
    </footer>
  );
}
