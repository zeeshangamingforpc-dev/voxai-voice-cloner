'use client';

import { useState } from 'react';
import { VoiceUpload } from './VoiceUpload';
import { ErrorMessage } from './ErrorMessage';
import { LoadingState } from './LoadingState';
import { validateVoiceName } from '@/lib/validation';
import { MAX_VOICE_NAME_LENGTH } from '@/lib/types';

interface VoiceCreatorProps {
  onVoiceReady: (voiceId: string, title: string) => void;
  readyVoiceTitle: string | null;
  onReset: () => void;
}

export function VoiceCreator({ onVoiceReady, readyVoiceTitle, onReset }: VoiceCreatorProps) {
  const [file, setFile] = useState<File | null>(null);
  const [voiceName, setVoiceName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreateVoice() {
    setError(null);

    if (!file) {
      setError('Please upload a valid audio file.');
      return;
    }

    const nameCheck = validateVoiceName(voiceName);
    if (!nameCheck.valid) {
      setError(nameCheck.error || 'Please give your voice a name.');
      return;
    }

    setIsCreating(true);

    try {
      const formData = new FormData();
      formData.append('audio', file);
      formData.append('voiceName', voiceName);

      const response = await fetch('/api/voice/create', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        setError(data.error || 'Something went wrong. Please try again.');
        setIsCreating(false);
        return;
      }

      onVoiceReady(data.voiceId, data.title);
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsCreating(false);
    }
  }

  if (readyVoiceTitle) {
    return (
      <div className="rounded-xl2 border border-base-border bg-base-800/70 p-5 shadow-card sm:p-6">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-signal-teal/15 text-signal-teal">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <div className="min-w-0">
            <p className="font-medium text-ink-100">Voice ready</p>
            <p className="truncate text-sm text-ink-500">"{readyVoiceTitle}" is ready to generate speech.</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onReset}
          className="mt-4 text-sm font-medium text-signal-violet transition-opacity hover:opacity-80"
        >
          Create a different voice
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-xl2 border border-base-border bg-base-800/70 p-5 shadow-card sm:p-6">
      <h2 className="font-display text-xl font-semibold text-ink-100">Create Your Voice</h2>
      <p className="mt-1 text-sm text-ink-500">
        Upload a clean, single-speaker sample. A few seconds works, but 30–60 seconds gives the most natural clone.
      </p>

      <div className="mt-5">
        <VoiceUpload file={file} onFileSelected={setFile} onError={setError} disabled={isCreating} />
      </div>

      <div className="mt-5">
        <label htmlFor="voice-name" className="mb-2 block text-sm font-medium text-ink-300">
          Voice name
        </label>
        <input
          id="voice-name"
          type="text"
          value={voiceName}
          onChange={(e) => setVoiceName(e.target.value)}
          placeholder="My Voice"
          maxLength={MAX_VOICE_NAME_LENGTH}
          disabled={isCreating}
          className="w-full rounded-lg border border-base-border bg-base-900 px-3.5 py-3 text-base text-ink-100 placeholder:text-ink-700 focus:border-signal-violet disabled:opacity-50"
        />
      </div>

      <ErrorMessage message={error} />

      <div className="mt-5">
        {isCreating ? (
          <LoadingState label="Creating your voice..." />
        ) : (
          <button
            type="button"
            onClick={handleCreateVoice}
            className="w-full rounded-full bg-signal-gradient px-6 py-3.5 text-base font-semibold text-base-950 shadow-glow transition-transform active:scale-95 sm:w-auto"
          >
            Create Voice
          </button>
        )}
      </div>

      <p className="mt-5 border-t border-base-border pt-4 text-xs leading-relaxed text-ink-700">
        Only upload voices you own or have permission to use.
      </p>
    </div>
  );
}
