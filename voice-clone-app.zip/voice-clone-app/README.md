# AI Voice Cloning

A simple, production-ready voice cloning and text-to-speech web app. Upload a short
audio sample, clone your voice, then type any text and generate speech in that voice.
Built with Next.js and powered by the [Fish Audio](https://fish.audio) API.

This project is written to be edited and deployed entirely from a phone via
GitHub + Vercel — no local setup required.

## What it does

1. You upload a voice sample (WAV, MP3, M4A, or OPUS).
2. The app validates the file and sends it to a secure backend route.
3. The backend creates a reusable voice model with Fish Audio.
4. You type text and generate speech in that cloned voice.
5. The generated audio plays in a real audio player, with seek, volume, and download.

There's no database, no payments, no accounts, and no fake functionality — every
control on the page does exactly what it says.

## 1. Requirements

- A [GitHub](https://github.com) account
- A [Vercel](https://vercel.com) account (free tier is fine)
- A [Fish Audio](https://fish.audio) account and API key

You do **not** need Node.js installed locally if you're deploying straight from
GitHub → Vercel. If you want to run it on a computer first, you'll need Node.js 18.18+.

## 2. Getting a Fish Audio API key

1. Go to [fish.audio](https://fish.audio) and create an account.
2. Open your account/developer settings and generate an API key.
3. Copy the key — you'll paste it into Vercel's environment variables in step 5.

## 3. Configuring environment variables

This project reads two environment variables:

| Variable      | Required | Description                                                                 |
|---------------|----------|-------------------------------------------------------------------------------|
| `FISH_API_KEY`| Yes      | Your Fish Audio API key. Server-side only — never exposed to the browser.     |
| `FISH_MODEL`  | No       | Which Fish Audio TTS model to use. Defaults to `s2.1-pro` if left unset.       |

Copy `.env.example` to `.env.local` if running locally:

```bash
cp .env.example .env.local
```

Then fill in your key:

```
FISH_API_KEY=your_real_key_here
FISH_MODEL=
```

Never commit `.env.local` — it's already in `.gitignore`.

## 4. Running locally (optional)

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## 5. Deploying to Vercel

1. Push this project to a GitHub repository (you can do this from the GitHub
   mobile app or github.com: create a new repo, then upload/commit these files).
2. Go to [vercel.com/new](https://vercel.com/new) and import that repository.
3. Vercel will detect this as a Next.js project automatically — no build
   configuration needed.
4. Before deploying (or right after, then redeploy), go to
   **Project Settings → Environment Variables** and add:
   - `FISH_API_KEY` = your Fish Audio API key
   - `FISH_MODEL` = leave blank unless you want a specific model
5. Click **Deploy**. Once it finishes, open the URL Vercel gives you — that's your
   live site.

```
GitHub  →  Import repository into Vercel  →  Add environment variables  →  Deploy  →  Open website
```

Any time you edit a file on GitHub (even from your phone's browser), Vercel
automatically redeploys the site.

## 6. Common errors

- **"Voice generation is not configured on the server yet."** — `FISH_API_KEY` is
  missing in Vercel's Environment Variables. Add it and redeploy.
- **"Please upload a valid audio file."** — the file isn't WAV/MP3/M4A/OPUS, or is
  empty/corrupted.
- **"Your audio file is too large."** — keep samples under 4MB (a minute or so of
  speech is plenty and well under this limit). This ceiling exists because Vercel's
  serverless functions cap incoming request bodies at 4.5MB regardless of app
  configuration.
- **"Too many voice creation requests" / "Too many generation requests."** — the
  built-in rate limiter is protecting against rapid-fire abuse. Wait a few minutes.
- **"Voice generation is temporarily unavailable."** — Fish Audio's API returned an
  error (bad key, outage, or account issue). Check your API key and Fish Audio
  account status.

## 7. Updating the Fish Audio integration later

All Fish Audio-specific request logic lives in **`lib/fish-audio.ts`** — it's the
only file that talks to `api.fish.audio`. If Fish Audio changes their API or you
want to add a new documented feature (e.g. multi-sample cloning, a different
model), that's the file to edit. The API routes in `app/api/voice/create/route.ts`
and `app/api/voice/generate/route.ts` handle validation, rate limiting, and error
responses, and call into `lib/fish-audio.ts` — they generally shouldn't need to
change.

Always check the current docs at [docs.fish.audio](https://docs.fish.audio) before
changing endpoint URLs or request fields, rather than guessing.

## Project structure

```
app/
  page.tsx              Main page (client-side flow: upload → clone → generate)
  layout.tsx            Root layout, fonts, metadata
  globals.css           Tailwind base styles and design tokens
  api/
    voice/create/route.ts     POST — creates a Fish Audio voice model
    voice/generate/route.ts   POST — generates speech, returns MP3 audio
components/
  Header.tsx, Hero.tsx, VoiceUpload.tsx, VoiceCreator.tsx,
  TextGenerator.tsx, AudioPlayer.tsx, Waveform.tsx,
  ErrorMessage.tsx, LoadingState.tsx, Footer.tsx
lib/
  fish-audio.ts          All Fish Audio API calls live here
  validation.ts          Shared client + server validation rules
  rate-limit.ts          Lightweight in-memory rate limiter
  types.ts               Shared types and constants
```

## Notes and limitations (by design, for v1)

- **No database.** Voice IDs and generated audio live only in the browser tab's
  state for the current session. Refreshing the page clears them (the voice
  itself still exists on Fish Audio's servers, tied to your API key).
- **Rate limiting is in-memory**, scoped to a single serverless instance. It stops
  casual abuse but isn't a substitute for infrastructure-level protection at
  scale — see the comment in `lib/rate-limit.ts` for upgrade paths.
- **Privacy:** only upload voices you own or have explicit permission to clone.
  This app doesn't claim to guarantee permanent deletion of any data — that
  depends on Fish Audio's own data retention, which you should check in their
  documentation if this matters for your use case.

## License

Use and modify freely for your own project.
