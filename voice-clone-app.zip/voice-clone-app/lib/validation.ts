import {
  ACCEPTED_AUDIO_EXTENSIONS,
  ACCEPTED_AUDIO_TYPES,
  MAX_AUDIO_BYTES,
  MAX_TEXT_LENGTH,
  MAX_VOICE_NAME_LENGTH,
  MIN_AUDIO_BYTES,
  SPEED_MAX,
  SPEED_MIN,
  VOLUME_MAX,
  VOLUME_MIN,
} from './types';

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

function getExtension(filename: string): string {
  const idx = filename.lastIndexOf('.');
  return idx === -1 ? '' : filename.slice(idx).toLowerCase();
}

export function validateAudioFile(file: File | null): ValidationResult {
  if (!file) {
    return { valid: false, error: 'Please upload a voice sample first.' };
  }

  if (file.size < MIN_AUDIO_BYTES) {
    return { valid: false, error: 'That file looks empty. Please upload a valid audio recording.' };
  }

  if (file.size > MAX_AUDIO_BYTES) {
    return { valid: false, error: `Your audio file is too large. Please keep it under ${MAX_AUDIO_BYTES / (1024 * 1024)}MB.` };
  }

  const extension = getExtension(file.name);
  const typeOk = ACCEPTED_AUDIO_TYPES.includes(file.type as (typeof ACCEPTED_AUDIO_TYPES)[number]);
  const extensionOk = ACCEPTED_AUDIO_EXTENSIONS.includes(extension);

  if (!typeOk && !extensionOk) {
    return {
      valid: false,
      error: 'Please upload a valid audio file (WAV, MP3, M4A, or OPUS).',
    };
  }

  return { valid: true };
}

export function validateVoiceName(name: string): ValidationResult {
  const trimmed = name.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: 'Please give your voice a name.' };
  }

  if (trimmed.length > MAX_VOICE_NAME_LENGTH) {
    return { valid: false, error: `Voice name must be ${MAX_VOICE_NAME_LENGTH} characters or fewer.` };
  }

  // Allow letters, numbers, spaces, and a small set of safe punctuation.
  const safePattern = /^[\p{L}\p{N}\s\-_.,'()]+$/u;
  if (!safePattern.test(trimmed)) {
    return { valid: false, error: 'Voice name contains characters that are not allowed.' };
  }

  return { valid: true };
}

export function sanitizeVoiceName(name: string): string {
  return name.trim().slice(0, MAX_VOICE_NAME_LENGTH);
}

export function validateGenerationText(text: string): ValidationResult {
  const trimmed = text.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: 'Please enter some text first.' };
  }

  if (trimmed.length > MAX_TEXT_LENGTH) {
    return { valid: false, error: `Text is too long. Please keep it under ${MAX_TEXT_LENGTH} characters.` };
  }

  return { valid: true };
}

export function validateVoiceId(voiceId: string): ValidationResult {
  if (!voiceId || typeof voiceId !== 'string') {
    return { valid: false, error: 'No voice selected. Please create a voice first.' };
  }
  // Fish Audio voice IDs are alphanumeric hex-style strings.
  if (!/^[a-zA-Z0-9_-]{4,128}$/.test(voiceId)) {
    return { valid: false, error: 'That voice reference looks invalid.' };
  }
  return { valid: true };
}

export function clampSpeed(value: number): number {
  if (Number.isNaN(value)) return 1;
  return Math.min(SPEED_MAX, Math.max(SPEED_MIN, value));
}

export function clampVolume(value: number): number {
  if (Number.isNaN(value)) return 0;
  return Math.min(VOLUME_MAX, Math.max(VOLUME_MIN, value));
}
