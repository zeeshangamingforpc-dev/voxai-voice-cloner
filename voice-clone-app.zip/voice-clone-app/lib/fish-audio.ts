/**
 * Fish Audio API service layer.
 *
 * Every request shape here follows Fish Audio's official documentation
 * (https://docs.fish.audio) as of this writing:
 *   - POST https://api.fish.audio/model      → create a reusable voice model
 *   - POST https://api.fish.audio/v1/tts     → generate speech from text
 *
 * Keeping all Fish Audio specifics in this one file means updating the
 * integration later (new model names, new fields) only touches this file.
 */

const FISH_API_BASE = 'https://api.fish.audio';

function getApiKey(): string {
  const key = process.env.FISH_API_KEY;
  if (!key) {
    throw new FishAudioConfigError('FISH_API_KEY is not configured on the server.');
  }
  return key;
}

/** Defaults to Fish Audio's general-purpose production model. Override via
 * env var if you want a different documented model (e.g. "s2.1-pro-free"
 * for free-tier development, or "s2-pro"). */
function getModel(): string {
  return process.env.FISH_MODEL?.trim() || 's2.1-pro';
}

export class FishAudioConfigError extends Error {}
export class FishAudioApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export interface CreateVoiceModelParams {
  title: string;
  description?: string;
  audio: Buffer;
  filename: string;
  mimeType: string;
}

export interface CreateVoiceModelResult {
  id: string;
  state: string;
  title: string;
}

/**
 * Creates a persistent, reusable voice model from a single reference sample
 * (POST /model, documented at docs.fish.audio/features/voice-cloning).
 * The resulting id is passed as `reference_id` to speech generation.
 */
export async function createVoiceModel(
  params: CreateVoiceModelParams
): Promise<CreateVoiceModelResult> {
  const apiKey = getApiKey();

  const form = new FormData();
  form.append('type', 'tts');
  form.append('title', params.title);
  if (params.description) form.append('description', params.description);
  form.append('visibility', 'private');
  form.append('train_mode', 'fast');
  form.append('enhance_audio_quality', 'true');
  form.append(
    'voices',
    new Blob([params.audio], { type: params.mimeType || 'application/octet-stream' }),
    params.filename
  );

  let response: Response;
  try {
    response = await fetch(`${FISH_API_BASE}/model`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
      body: form,
    });
  } catch (err) {
    throw new FishAudioApiError('Could not reach Fish Audio. Please try again.', 0);
  }

  if (!response.ok) {
    const message = await safeErrorMessage(response);
    throw new FishAudioApiError(message, response.status);
  }

  const data = await response.json();
  const id: string | undefined = data?._id ?? data?.id;
  const state: string = data?.state ?? 'created';

  if (!id) {
    throw new FishAudioApiError('Fish Audio did not return a voice id.', 502);
  }

  return { id, state, title: params.title };
}

export interface GenerateSpeechParams {
  text: string;
  referenceId: string;
  speed: number;
  volume: number;
}

export interface GenerateSpeechResult {
  audio: Buffer;
  contentType: string;
}

/**
 * Generates speech for `text` in the voice identified by `referenceId`
 * (POST /v1/tts, documented at docs.fish.audio/features/text-to-speech).
 * Requests MP3 output so the frontend can play and download it directly.
 */
export async function generateSpeech(
  params: GenerateSpeechParams
): Promise<GenerateSpeechResult> {
  const apiKey = getApiKey();
  const model = getModel();

  const body = {
    text: params.text,
    reference_id: params.referenceId,
    format: 'mp3',
    prosody: {
      speed: params.speed,
      volume: params.volume,
    },
  };

  let response: Response;
  try {
    response = await fetch(`${FISH_API_BASE}/v1/tts`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        model,
      },
      body: JSON.stringify(body),
    });
  } catch (err) {
    throw new FishAudioApiError('Could not reach Fish Audio. Please try again.', 0);
  }

  if (!response.ok) {
    const message = await safeErrorMessage(response);
    throw new FishAudioApiError(message, response.status);
  }

  const arrayBuffer = await response.arrayBuffer();
  const contentType = response.headers.get('content-type') || 'audio/mpeg';

  return { audio: Buffer.from(arrayBuffer), contentType };
}

async function safeErrorMessage(response: Response): Promise<string> {
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const data = await response.json();
      const detail = data?.error || data?.message || data?.detail;
      if (typeof detail === 'string') return mapStatusToFriendlyMessage(response.status, detail);
    } else {
      await response.text();
    }
  } catch {
    // fall through to generic message
  }
  return mapStatusToFriendlyMessage(response.status);
}

function mapStatusToFriendlyMessage(status: number, detail?: string): string {
  if (status === 401 || status === 403) {
    return 'Voice generation is temporarily unavailable. Please try again later.';
  }
  if (status === 429) {
    return 'Fish Audio is rate-limiting requests right now. Please wait a moment and try again.';
  }
  if (status === 413) {
    return 'Your audio file is too large.';
  }
  if (status >= 500) {
    return 'Voice generation is temporarily unavailable. Please try again later.';
  }
  return detail && detail.length < 200 ? detail : 'Something went wrong. Please try again.';
}
