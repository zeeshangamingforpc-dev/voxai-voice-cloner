export interface CreateVoiceSuccess {
  success: true;
  voiceId: string;
  state: 'created' | 'trained' | 'failed' | string;
  title: string;
}

export interface GenerateSpeechSuccessMeta {
  success: true;
  format: 'mp3';
}

export interface ApiError {
  success: false;
  error: string;
}

export type CreateVoiceResponse = CreateVoiceSuccess | ApiError;

/** Options a user can actually control, all of which map to real,
 * documented Fish Audio TTS request fields (`prosody.speed`, `prosody.volume`).
 * Nothing here is decorative — if a control exists, it changes the request. */
export interface SpeechOptions {
  speed: number; // 0.5 – 2.0, Fish Audio's documented prosody.speed range
  volume: number; // -20 – 20 dB, Fish Audio's documented prosody.volume range
}

export const SPEED_MIN = 0.5;
export const SPEED_MAX = 2.0;
export const VOLUME_MIN = -20;
export const VOLUME_MAX = 20;

// Vercel serverless functions cap incoming request bodies at 4.5MB regardless
// of app-level config, so the ceiling here is set safely under that limit.
export const MAX_AUDIO_BYTES = 4 * 1024 * 1024; // 4MB reference sample ceiling
export const MIN_AUDIO_BYTES = 2 * 1024; // reject essentially-empty files

export const ACCEPTED_AUDIO_TYPES = [
  'audio/wav',
  'audio/x-wav',
  'audio/mpeg',
  'audio/mp3',
  'audio/mp4',
  'audio/x-m4a',
  'audio/m4a',
  'audio/opus',
  'audio/ogg',
] as const;

export const ACCEPTED_AUDIO_EXTENSIONS = ['.wav', '.mp3', '.m4a', '.opus', '.ogg'];

export const MAX_TEXT_LENGTH = 800;
export const MAX_VOICE_NAME_LENGTH = 60;
