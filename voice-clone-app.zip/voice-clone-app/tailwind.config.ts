import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#0A0C10',
          900: '#0F1216',
          800: '#14181E',
          700: '#1B2028',
          600: '#242A34',
          border: '#232A34',
        },
        ink: {
          100: '#F4F6F8',
          300: '#C4CAD3',
          500: '#8B93A1',
          700: '#5A616D',
        },
        signal: {
          violet: '#7C6CFF',
          teal: '#2BD9B9',
          amber: '#FFB454',
          red: '#FF6B6B',
        },
      },
      fontFamily: {
        display: ['var(--font-sora)', 'system-ui', 'sans-serif'],
        body: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-jbmono)', 'ui-monospace', 'monospace'],
      },
      backgroundImage: {
        'signal-gradient': 'linear-gradient(135deg, #7C6CFF 0%, #2BD9B9 100%)',
        'radial-fade':
          'radial-gradient(60% 60% at 50% 0%, rgba(124,108,255,0.16) 0%, rgba(10,12,16,0) 70%)',
      },
      boxShadow: {
        card: '0 1px 0 0 rgba(255,255,255,0.03) inset, 0 8px 24px -12px rgba(0,0,0,0.6)',
        glow: '0 0 0 1px rgba(124,108,255,0.4), 0 0 24px -4px rgba(124,108,255,0.5)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        'bar-bounce': {
          '0%, 100%': { transform: 'scaleY(0.3)' },
          '50%': { transform: 'scaleY(1)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'bar-bounce': 'bar-bounce 1s ease-in-out infinite',
        'fade-up': 'fade-up 0.5s ease-out both',
      },
    },
  },
  plugins: [],
};

export default config;
